
#define STR_MAX 254
#define FILE_LINE_MAX 100

char lineBuffer[][100];
int current_line_number = 0;


void buffer_aline(char *str);

/**
 * Display a line in a way which no word would be split because of the size of the screen
 * @param str   Input line in char array
 */
void buffer_aline(char *str){
    uint8_t current_line_length = 0;
    uint8_t max_line_length = 255;
    uint8_t char_width = 6; //5 for the character + 1 for space between characters
    uint8_t word_width = 0;


    char s[STR_MAX+1];      //Copy input String
    strncpy(s,str,STR_MAX);

    //Local line buffer for the current line
    //char* linearray;
    //strcpy(linearray, "");

    char *pch;
    pch = strtok (s," ");
    while (pch != NULL){
        //Measure word length
        word_width = char_width * strlen(pch);
        
        //Check if there is space for the next word to be place in the same line
        if(current_line_length+word_width > max_line_length){
        	//strcpy(lineBuffer[current_line_number], linearray);	//Store the last line into lineBuffer
        	//strcpy(linearray,"");		//Empty linearray
            current_line_number++;
            current_line_length = 0;    //Reset current line length
        }

        //Concatenate word into linearray
        strcpy(lineBuffer[current_line_number], pch);
        //strcat(linearray, pch);
        //strcat(linearray, " "); //Insert the space back after word being splited by space   
		

        //TODO REMOVE
        /*strcpy(lineBuffer[current_line_number], pch);
        current_line_number++;
        current_line_length = 0;*/

        pch = strtok (NULL, " ");
        current_line_length = current_line_length + word_width; //Update current word width
    }

    //strncpy(lineBuffer[current_line_number], linearray, sizeof(linearray));	//Store the last line into lineBuffer
	//strncpy(linearray,"",0);		//Empty linearray
    //current_line_number++;

    current_line_length = 0;
    word_width = 0;
}