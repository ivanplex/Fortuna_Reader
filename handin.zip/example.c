#include "display.h"
#include <avr/pgmspace.h>


void init(void);

int main(void) {

	start_screen();

	return 0;

}