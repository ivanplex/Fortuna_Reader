/* COMP2215 15/16: Task 02 */

#include <avr/io.h>
#include "lcd.h"
#include <util/delay.h>

void init(void);

void main(void) {
    init();

    println("This is hello from Ivan.", LIGHT_CYAN);
    println("Don't look at him, look at me!", LIME);
    
}


void init(void) {
    /* 8MHz clock, no prescaling (DS, p. 48) */
    CLKPR = (1 << CLKPCE);
    CLKPR = 0;

    init_lcd();
}

void println(char *input, uint16_t color){

    display_color(color, BLACK);
    display_string_slowly(input);
    display_string_slowly("\n");
}

void display_string_slowly(char *str) {
    uint8_t i;
    for(i=0; str[i]; i++){ 
        display_char('-');
        _delay_ms(100);
        display_backspace();
        display_char(str[i]);
	    _delay_ms(100);
    }
}

void display_backspace(void) {
    display.x -= 6;
}